import React, { useState } from 'react';
import { SKILL_CATEGORIES } from '../data/skills';
import { Layers, Server, Cpu, Zap, Wrench } from 'lucide-react';

export const Skills: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('all');

  const tabs = [
    { id: 'all', label: 'All Technologies' },
    { id: 'frontend', label: 'Frontend' },
    { id: 'backend', label: 'Backend & APIs' },
    { id: 'ai', label: 'AI Integration' },
    { id: 'automation', label: 'Automation' },
    { id: 'tools', label: 'Tools' },
  ];

  const getCategoryIcon = (id: string) => {
    switch (id) {
      case 'frontend':
        return <Layers className="w-4 h-4 text-[#8B5CF6]" />;
      case 'backend':
        return <Server className="w-4 h-4 text-[#8B5CF6]" />;
      case 'ai':
        return <Cpu className="w-4 h-4 text-[#8B5CF6]" />;
      case 'automation':
        return <Zap className="w-4 h-4 text-[#8B5CF6]" />;
      default:
        return <Wrench className="w-4 h-4 text-[#8B5CF6]" />;
    }
  };

  const filteredCategories =
    activeTab === 'all'
      ? SKILL_CATEGORIES
      : SKILL_CATEGORIES.filter((cat) => cat.id === activeTab);

  return (
    <section id="skills" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-2xl mb-8">
          <p className="text-xs uppercase font-mono-custom text-[#7C3AED] tracking-wider mb-2 font-semibold">
            Technical Stack
          </p>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-[#0F172A] tracking-tight">
            Tools &amp; Technologies
          </h2>
          <p className="text-sm text-slate-500 mt-2">
            Practical skills verified across real projects and codebases.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-8 no-scrollbar">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 text-xs font-semibold rounded-xl whitespace-nowrap transition-all duration-200 cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-[#8B5CF6] text-white shadow-md shadow-purple-500/25'
                  : 'bg-slate-100 text-slate-600 hover:text-[#0F172A] hover:bg-slate-200/80'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCategories.map((cat) => (
            <div
              key={cat.id}
              className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-xl hover:shadow-purple-500/10 hover:border-purple-200 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-3 mb-2.5">
                  <div className="p-2 rounded-xl bg-purple-50 border border-purple-100">
                    {getCategoryIcon(cat.id)}
                  </div>
                  <h3 className="font-display text-base font-bold text-[#0F172A] tracking-tight">
                    {cat.title}
                  </h3>
                </div>

                <p className="text-xs text-slate-500 mb-4 leading-relaxed">
                  {cat.description}
                </p>

                {/* Skill Items as colorful tags */}
                <div className="flex flex-wrap gap-1.5">
                  {cat.skills.map((skill) => (
                    <div
                      key={skill.name}
                      className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs rounded-lg border transition-colors ${
                        skill.highlight
                          ? 'bg-purple-50 text-[#7C3AED] border-purple-200 font-semibold'
                          : 'bg-slate-50 text-slate-700 border-slate-200'
                      }`}
                    >
                      <span>{skill.name}</span>
                      {skill.note && (
                        <span className="text-[10px] font-mono-custom text-slate-500 bg-white px-1.5 py-0.2 rounded border border-slate-200">
                          {skill.note}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-mono-custom text-slate-400">
                <span>{cat.skills.length} skills</span>
                <span className="text-[#8B5CF6]">Active Stack</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
