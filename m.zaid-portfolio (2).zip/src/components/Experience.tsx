import React from 'react';
import { BUILDING_MILESTONES } from '../data/experience';
import { Sparkles, Code2, GraduationCap } from 'lucide-react';

export const Experience: React.FC = () => {
  return (
    <section id="building" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <p className="text-xs uppercase font-mono-custom text-[#7C3AED] tracking-wider mb-2 font-semibold">
            Timeline
          </p>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-[#0F172A] tracking-tight">
            Building &amp; Learning
          </h2>
          <p className="text-sm text-slate-500 mt-2">
            Academic progression at UET Lahore, practical repositories, and skill development.
          </p>
        </div>

        {/* Timeline Grid */}
        <div className="relative border-l border-slate-200 ml-4 sm:ml-6 pl-6 sm:pl-8 space-y-8">
          {BUILDING_MILESTONES.map((item, idx) => (
            <div key={idx} className="relative group">
              {/* Timeline Indicator Dot */}
              <div className="absolute -left-[31px] sm:-left-[39px] top-1.5 w-3.5 h-3.5 rounded-full bg-white border-2 border-[#8B5CF6] group-hover:bg-[#8B5CF6] group-hover:shadow-[0_0_8px_rgba(139,92,246,0.6)] transition-all" />

              <div className="p-6 rounded-2xl bg-slate-50/60 border border-slate-200/80 hover:bg-white hover:shadow-lg hover:shadow-purple-500/5 hover:border-purple-200 hover:-translate-y-0.5 transition-all">
                {/* Meta Bar */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <span className="text-xs font-mono-custom text-[#7C3AED] bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200 font-semibold">
                    {item.period}
                  </span>
                  <span className="text-xs font-mono-custom text-slate-400">
                    {item.focus}
                  </span>
                </div>

                {/* Title */}
                <h3 className="font-display text-base sm:text-lg font-bold text-[#0F172A] mb-1.5 tracking-tight group-hover:text-[#7C3AED] transition-colors">
                  {item.title}
                </h3>

                {/* Description */}
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-3.5">
                  {item.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5">
                  {item.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[11px] font-mono-custom px-2.5 py-0.5 rounded-md bg-white text-slate-600 border border-slate-200"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Education Highlight Strip */}
        <div className="mt-12 p-6 rounded-2xl bg-purple-50/50 border border-purple-100 grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-700">
          <div className="flex items-start gap-3">
            <GraduationCap className="w-5 h-5 text-[#8B5CF6] shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-[#0F172A]">Degree Program</p>
              <p className="text-slate-600 mt-0.5">BS Computer Science at UET Lahore (graduating 2029).</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Code2 className="w-5 h-5 text-[#8B5CF6] shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-[#0F172A]">Practical Philosophy</p>
              <p className="text-slate-600 mt-0.5">Code tested and deployed through public GitHub repositories.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-[#8B5CF6] shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-[#0F172A]">Active Focus</p>
              <p className="text-slate-600 mt-0.5">FastAPI microservices, Gemini API prompt workflows &amp; n8n pipelines.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
