import React from 'react';
import { SERVICES } from '../data/services';
import { Layout, BotMessageSquare, Sparkles, Workflow, Cpu, ArrowRight } from 'lucide-react';

export const Services: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Layout':
        return <Layout className="w-5 h-5 text-[#8B5CF6]" />;
      case 'BotMessageSquare':
        return <BotMessageSquare className="w-5 h-5 text-[#8B5CF6]" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-[#8B5CF6]" />;
      case 'Workflow':
        return <Workflow className="w-5 h-5 text-[#8B5CF6]" />;
      case 'Cpu':
        return <Cpu className="w-5 h-5 text-[#8B5CF6]" />;
      default:
        return <Layout className="w-5 h-5 text-[#8B5CF6]" />;
    }
  };

  return (
    <section id="services" className="py-20 bg-white relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <p className="text-xs uppercase font-mono-custom text-[#7C3AED] tracking-wider mb-2 font-semibold">
            Services
          </p>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-[#0F172A] tracking-tight">
            How I Can Help Your Team
          </h2>
          <p className="text-sm text-slate-500 mt-2">
            Targeted development mapped to my verified technical competencies.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className="p-7 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-xl hover:shadow-purple-500/10 hover:border-purple-200 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Header */}
                <div className="flex items-center gap-3.5 mb-4">
                  <div className="p-3 rounded-2xl bg-purple-50 border border-purple-100 text-[#8B5CF6] group-hover:bg-[#8B5CF6] group-hover:text-white transition-colors">
                    {getIcon(service.icon)}
                  </div>
                  <h3 className="font-display text-base sm:text-lg font-bold text-[#0F172A] tracking-tight group-hover:text-[#7C3AED] transition-colors">
                    {service.title}
                  </h3>
                </div>

                {/* Problem & Solution */}
                <div className="space-y-2.5 mb-5 text-xs sm:text-sm">
                  <div>
                    <span className="font-mono-custom text-rose-500 font-semibold uppercase tracking-wider block mb-0.5 text-[10px]">
                      Challenge
                    </span>
                    <p className="text-slate-500 leading-relaxed">
                      {service.problem}
                    </p>
                  </div>
                  <div>
                    <span className="font-mono-custom text-[#7C3AED] font-semibold uppercase tracking-wider block mb-0.5 text-[10px]">
                      Solution
                    </span>
                    <p className="text-[#0F172A] font-medium leading-relaxed">
                      {service.solution}
                    </p>
                  </div>
                </div>
              </div>

              {/* Technologies */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                <div className="flex flex-wrap gap-1.5">
                  {service.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="text-[11px] font-mono-custom px-2.5 py-0.5 rounded-md bg-slate-50 text-slate-600 border border-slate-200"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                <a
                  href="#contact"
                  className="text-xs text-[#7C3AED] hover:text-[#6D28D9] font-semibold flex items-center gap-1 shrink-0"
                >
                  <span>Inquire</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
