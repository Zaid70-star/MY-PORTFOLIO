import React, { useState } from 'react';
import { Mail, Github, Linkedin, Copy, Check, Send, MapPin, Sparkles } from 'lucide-react';

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    projectType: 'Modern Web Application',
    message: '',
  });

  const [copiedEmail, setCopiedEmail] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const directEmail = 'mzaidi1326@gmail.com';

  const handleCopyEmail = async () => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(directEmail);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = directEmail;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2000);
    } catch {
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2000);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Project Inquiry: ${formData.projectType} — ${formData.name}`);
    const body = encodeURIComponent(
      `Hi Muhammad Zaid,\n\nName: ${formData.name}\nEmail: ${formData.email}\nProject Type: ${formData.projectType}\n\nMessage:\n${formData.message}`
    );
    window.location.href = `mailto:${directEmail}?subject=${subject}&body=${body}`;
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 bg-white relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <p className="text-xs uppercase font-mono-custom text-[#7C3AED] tracking-wider mb-2 font-semibold">
            Contact
          </p>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0F172A] tracking-tight">
            Let's Talk About Your Project.
          </h2>
          <p className="text-sm sm:text-base text-slate-500 mt-2">
            Have a project in mind, an automation challenge, or a position to discuss? Send a message.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Column: Direct Info */}
          <div className="lg:col-span-5 space-y-5">
            <div className="p-7 rounded-2xl bg-slate-50/60 border border-slate-200/80 space-y-4">
              <h3 className="font-display text-lg font-bold text-[#0F172A]">Direct Communication</h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Reach out directly via email or connect on professional channels. I typically respond within 24 hours.
              </p>

              {/* Email Copy Box */}
              <div className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-xs flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 overflow-hidden">
                  <Mail className="w-4 h-4 text-[#8B5CF6] shrink-0" />
                  <span className="text-xs sm:text-sm font-mono-custom text-[#0F172A] font-semibold truncate">
                    {directEmail}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="px-3 py-1.5 text-xs font-mono-custom text-slate-700 hover:text-[#7C3AED] bg-slate-50 hover:bg-purple-50 rounded-lg border border-slate-200 transition-colors inline-flex items-center gap-1 shrink-0 active:scale-95 cursor-pointer"
                  title="Copy email"
                >
                  {copiedEmail ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-600 font-semibold">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>

              {/* Meta */}
              <div className="space-y-2 pt-2 text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#8B5CF6] shrink-0" />
                  <span>Lahore, Pakistan · Open to Remote</span>
                </div>
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#8B5CF6] shrink-0" />
                  <span>Available for Freelance &amp; Junior Roles</span>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
              <div className="flex flex-col gap-2 text-xs">
                <a
                  href="https://github.com/Zaid70-star"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between text-slate-700 hover:text-[#7C3AED] group p-2.5 rounded-xl hover:bg-purple-50/50 transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <Github className="w-4 h-4 text-[#8B5CF6]" />
                    <span className="font-medium">github.com/Zaid70-star</span>
                  </span>
                  <span className="text-[11px] font-mono-custom text-slate-400 group-hover:text-[#7C3AED]">
                    Repositories →
                  </span>
                </a>

                <a
                  href="https://www.linkedin.com/in/muhammad-zaid-6698b4382/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between text-slate-700 hover:text-[#7C3AED] group p-2.5 rounded-xl hover:bg-purple-50/50 transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <Linkedin className="w-4 h-4 text-[#8B5CF6]" />
                    <span className="font-medium">LinkedIn Profile</span>
                  </span>
                  <span className="text-[11px] font-mono-custom text-slate-400 group-hover:text-[#7C3AED]">
                    Connect →
                  </span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="p-7 sm:p-8 rounded-3xl bg-slate-50/60 border border-slate-200/80 shadow-xs relative">
              <h3 className="font-display text-lg sm:text-xl font-bold text-[#0F172A] mb-1">Send a Message</h3>
              <p className="text-xs text-slate-500 mb-6">
                Fill out the quick form below. It prepares an email draft directly in your preferred client.
              </p>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-xs font-mono-custom text-slate-600 mb-1.5 font-medium">
                      Your Name
                    </label>
                    <input
                      id="name"
                      type="text"
                      required
                      placeholder="e.g. Alex Miller"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl text-[#0F172A] placeholder-slate-400 focus:outline-none focus:border-[#8B5CF6] focus:ring-2 focus:ring-purple-500/20 transition-all"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-xs font-mono-custom text-slate-600 mb-1.5 font-medium">
                      Your Email
                    </label>
                    <input
                      id="email"
                      type="email"
                      required
                      placeholder="e.g. alex@company.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl text-[#0F172A] placeholder-slate-400 focus:outline-none focus:border-[#8B5CF6] focus:ring-2 focus:ring-purple-500/20 transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="projectType" className="block text-xs font-mono-custom text-slate-600 mb-1.5 font-medium">
                    Project Type
                  </label>
                  <select
                    id="projectType"
                    value={formData.projectType}
                    onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                    className="w-full px-4 py-3 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl text-[#0F172A] focus:outline-none focus:border-[#8B5CF6] focus:ring-2 focus:ring-purple-500/20 transition-all cursor-pointer"
                  >
                    <option value="Modern Web Application">Modern Web Application (React &amp; Tailwind)</option>
                    <option value="AI Chatbot or API Feature">AI Chatbot or API Feature (Gemini &amp; FastAPI)</option>
                    <option value="Workflow Automation">Workflow Automation (n8n &amp; Webhooks)</option>
                    <option value="REST API Integration">REST API Integration</option>
                    <option value="Other Project Inquiry">Other Project Inquiry</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block text-xs font-mono-custom text-slate-600 mb-1.5 font-medium">
                    Brief Overview
                  </label>
                  <textarea
                    id="message"
                    required
                    rows={4}
                    placeholder="Briefly describe what you need built or automated..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-3 text-xs sm:text-sm bg-white border border-slate-200 rounded-xl text-[#0F172A] placeholder-slate-400 focus:outline-none focus:border-[#8B5CF6] focus:ring-2 focus:ring-purple-500/20 transition-all resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2 px-7 py-3.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#8B5CF6] hover:bg-[#7C3AED] rounded-xl transition-all shadow-md shadow-purple-500/25 hover:shadow-lg hover:shadow-purple-500/35 hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Message</span>
                </button>

                {submitted && (
                  <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Your email draft has been generated! You can also email directly to {directEmail}.</span>
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
