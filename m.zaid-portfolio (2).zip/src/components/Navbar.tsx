import React, { useState, useEffect } from 'react';
import { Menu, X, Github, Linkedin } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  const navLinks = [
    { name: 'Home', href: '#home', id: 'home' },
    { name: 'About', href: '#about', id: 'about' },
    { name: 'Skills', href: '#skills', id: 'skills' },
    { name: 'Projects', href: '#projects', id: 'projects' },
    { name: 'Services', href: '#services', id: 'services' },
    { name: 'Learning', href: '#building', id: 'building' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      const sections = ['home', 'about', 'skills', 'projects', 'services', 'building', 'contact'];
      const scrollPos = window.scrollY + 140;

      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el && el.offsetTop <= scrollPos) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/90 backdrop-blur-md shadow-sm border-b border-slate-200/80 py-3'
          : 'bg-transparent py-4 sm:py-6'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Wordmark matching reference circular purple badge + bold name */}
          <a
            href="#home"
            className="group flex items-center gap-2.5 text-[#0F172A] transition-transform active:scale-95"
          >
            <span className="w-9 h-9 rounded-full bg-[#8B5CF6] text-white font-display font-bold text-sm flex items-center justify-center shadow-md shadow-purple-500/25 group-hover:bg-[#7C3AED] transition-colors">
              Z
            </span>
            <span className="font-display font-bold text-lg sm:text-xl text-[#0F172A] tracking-tight group-hover:text-[#7C3AED] transition-colors">
              Muhammad Zaid
            </span>
          </a>

          {/* Desktop & Tablet Navigation */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.name}
                  href={link.href}
                  className={`text-sm font-medium transition-colors relative py-1 ${
                    isActive
                      ? 'text-[#7C3AED] font-semibold'
                      : 'text-slate-600 hover:text-[#7C3AED]'
                  }`}
                >
                  {link.name}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#8B5CF6] rounded-full" />
                  )}
                </a>
              );
            })}
          </nav>

          {/* Action Area: Social Icons + Solid Purple Contact Button from Reference */}
          <div className="hidden sm:flex items-center gap-3">
            <a
              href="https://github.com/Zaid70-star"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-slate-500 hover:text-[#7C3AED] hover:bg-slate-100 rounded-lg transition-colors"
              title="GitHub Profile"
              aria-label="GitHub Profile"
            >
              <Github className="w-4 h-4" />
            </a>

            <a
              href="https://www.linkedin.com/in/muhammad-zaid-6698b4382/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-slate-500 hover:text-[#7C3AED] hover:bg-slate-100 rounded-lg transition-colors"
              title="LinkedIn Profile"
              aria-label="LinkedIn Profile"
            >
              <Linkedin className="w-4 h-4" />
            </a>

            <a
              href="#contact"
              className="px-5 py-2.5 text-xs font-semibold text-white bg-[#8B5CF6] hover:bg-[#7C3AED] rounded-lg transition-all shadow-md shadow-purple-500/25 hover:shadow-lg hover:shadow-purple-500/35 hover:-translate-y-0.5 active:translate-y-0"
            >
              Contact
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href="#contact"
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-[#8B5CF6] rounded-lg shadow-sm"
            >
              Contact
            </a>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-700 hover:bg-slate-100 transition-colors"
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6 text-[#7C3AED]" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 shadow-xl animate-in slide-in-from-top-2 duration-200 mt-2">
          <nav className="flex flex-col gap-1">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`px-3 py-2.5 text-sm font-medium rounded-lg transition-colors flex items-center justify-between ${
                    isActive
                      ? 'text-[#7C3AED] bg-purple-50 font-semibold'
                      : 'text-slate-700 hover:text-[#7C3AED] hover:bg-slate-50'
                  }`}
                >
                  <span>{link.name}</span>
                  {isActive && <span className="w-1.5 h-1.5 rounded-full bg-[#8B5CF6]" />}
                </a>
              );
            })}
          </nav>

          <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <a
                href="https://github.com/Zaid70-star"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 text-slate-600 hover:text-[#7C3AED] bg-slate-50 rounded-lg border border-slate-200"
                aria-label="GitHub Profile"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href="https://www.linkedin.com/in/muhammad-zaid-6698b4382/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 text-slate-600 hover:text-[#7C3AED] bg-slate-50 rounded-lg border border-slate-200"
                aria-label="LinkedIn Profile"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            </div>

            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#8B5CF6] hover:bg-[#7C3AED] rounded-lg shadow-sm"
            >
              Let's Talk
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
