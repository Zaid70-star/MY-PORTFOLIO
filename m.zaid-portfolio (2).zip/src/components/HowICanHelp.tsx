import React from 'react';
import { ArrowUpRight, MessageSquareCode, Github } from 'lucide-react';

export const HowICanHelp: React.FC = () => {
  return (
    <section className="py-16 bg-slate-50/60 border-b border-slate-200/60">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-purple-100/70 via-white to-purple-50/50 border border-purple-200/60 shadow-lg shadow-purple-500/5 relative overflow-hidden">
          <div className="relative z-10 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 text-xs font-mono-custom text-[#7C3AED] bg-white rounded-full shadow-xs border border-purple-200 mb-4 font-semibold">
              <MessageSquareCode className="w-3.5 h-3.5" />
              <span>Direct Collaboration</span>
            </div>

            <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#0F172A] tracking-tight leading-snug mb-3">
              Need a modern web app or business automation?
            </h3>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed mb-6">
              Whether you need a fresh React interface, a custom AI endpoint, or an n8n webhook workflow to automate repetitive manual work, let's discuss your requirements.
            </p>

            <div className="flex flex-wrap items-center gap-3.5">
              <a
                href="#contact"
                className="inline-flex items-center gap-2 px-7 py-3.5 text-xs font-semibold uppercase tracking-wider text-white bg-[#8B5CF6] hover:bg-[#7C3AED] rounded-xl transition-all shadow-md shadow-purple-500/25 hover:shadow-lg hover:shadow-purple-500/35 hover:-translate-y-0.5"
              >
                <span>Start a Conversation</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>

              <a
                href="https://github.com/Zaid70-star"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-slate-700 hover:text-[#0F172A] bg-white hover:bg-slate-50 rounded-xl border border-slate-200 shadow-xs transition-all hover:-translate-y-0.5"
              >
                <Github className="w-4 h-4 text-[#8B5CF6]" />
                <span>Browse Code on GitHub</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
