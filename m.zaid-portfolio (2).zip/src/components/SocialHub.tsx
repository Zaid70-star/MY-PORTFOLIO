import React from 'react';
import { Github, Linkedin, ArrowUpRight, FolderGit2, Star, GitBranch } from 'lucide-react';

export const SocialHub: React.FC = () => {
  return (
    <section className="py-16 bg-slate-50/60 border-y border-slate-200/60">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* GitHub Highlight Card */}
          <div className="p-7 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-xl hover:shadow-purple-500/10 hover:border-purple-200 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between group">
            <div>
              <div className="flex items-center justify-between mb-3.5">
                <div className="p-3 rounded-2xl bg-purple-50 border border-purple-100 text-[#8B5CF6] group-hover:bg-[#8B5CF6] group-hover:text-white transition-colors">
                  <Github className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono-custom text-[#7C3AED] bg-purple-50 px-3 py-1 rounded-full border border-purple-200 font-semibold">
                  @Zaid70-star
                </span>
              </div>

              <h3 className="font-display text-xl font-bold text-[#0F172A] mb-1.5 group-hover:text-[#7C3AED] transition-colors">
                GitHub Repositories
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
                Explore open-source codebases including React web apps, FastAPI backends, Gemini AI experiments, and n8n workflows.
              </p>

              <div className="grid grid-cols-3 gap-2.5 p-3.5 bg-slate-50 border border-slate-100 rounded-xl mb-6 text-center text-xs">
                <div>
                  <div className="flex items-center justify-center gap-1 text-slate-400 font-mono-custom mb-1">
                    <FolderGit2 className="w-3.5 h-3.5 text-[#8B5CF6]" />
                  </div>
                  <p className="font-bold text-[#0F172A]">Public Repos</p>
                  <p className="text-[11px] text-slate-500">React &amp; Python</p>
                </div>
                <div>
                  <div className="flex items-center justify-center gap-1 text-slate-400 font-mono-custom mb-1">
                    <GitBranch className="w-3.5 h-3.5 text-[#8B5CF6]" />
                  </div>
                  <p className="font-bold text-[#0F172A]">Active Code</p>
                  <p className="text-[11px] text-slate-500">Fresh Commits</p>
                </div>
                <div>
                  <div className="flex items-center justify-center gap-1 text-slate-400 font-mono-custom mb-1">
                    <Star className="w-3.5 h-3.5 text-[#8B5CF6]" />
                  </div>
                  <p className="font-bold text-[#0F172A]">Open Work</p>
                  <p className="text-[11px] text-slate-500">Job Finder &amp; AI</p>
                </div>
              </div>
            </div>

            <a
              href="https://github.com/Zaid70-star"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold uppercase tracking-wider text-slate-700 hover:text-[#7C3AED] bg-slate-50 hover:bg-purple-50 rounded-xl border border-slate-200 hover:border-purple-200 transition-all"
            >
              <span>Explore GitHub Repos</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>

          {/* LinkedIn Highlight Card */}
          <div className="p-7 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-xl hover:shadow-purple-500/10 hover:border-purple-200 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between group">
            <div>
              <div className="flex items-center justify-between mb-3.5">
                <div className="p-3 rounded-2xl bg-purple-50 border border-purple-100 text-[#8B5CF6] group-hover:bg-[#8B5CF6] group-hover:text-white transition-colors">
                  <Linkedin className="w-5 h-5" />
                </div>
                <span className="text-xs font-mono-custom text-[#7C3AED] bg-purple-50 px-3 py-1 rounded-full border border-purple-200 font-semibold">
                  Professional Network
                </span>
              </div>

              <h3 className="font-display text-xl font-bold text-[#0F172A] mb-1.5 group-hover:text-[#7C3AED] transition-colors">
                Connect on LinkedIn
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
                Available for freelance engagements, junior developer positions, and collaborations with founders and engineering teams.
              </p>

              <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl mb-6 text-xs text-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Target Roles:</span>
                  <span className="font-semibold text-[#0F172A]">Frontend &amp; AI Integration</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Location:</span>
                  <span className="font-semibold text-[#0F172A]">Lahore, Pakistan (Remote Open)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Languages:</span>
                  <span className="font-semibold text-[#0F172A]">English / Urdu</span>
                </div>
              </div>
            </div>

            <a
              href="https://www.linkedin.com/in/muhammad-zaid-6698b4382/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold uppercase tracking-wider text-white bg-[#8B5CF6] hover:bg-[#7C3AED] rounded-xl transition-all shadow-md shadow-purple-500/25"
            >
              <span>Connect on LinkedIn</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
