import React, { useState } from 'react';
import { FEATURED_PROJECTS } from '../data/projects';
import { Project } from '../types';
import { ExternalLink, Github, Check, Code, Layers, Bot, Workflow, Image as ImageIcon, X, Sparkles } from 'lucide-react';

export const Projects: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [customScreenshots, setCustomScreenshots] = useState<Record<string, string>>({});
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const filterTabs = [
    { id: 'all', label: 'All Projects' },
    { id: 'web', label: 'Web Applications' },
    { id: 'ai', label: 'AI Integrations' },
    { id: 'automation', label: 'Automations' },
  ];

  const filteredProjects =
    activeCategory === 'all'
      ? FEATURED_PROJECTS
      : FEATURED_PROJECTS.filter((p) => p.category === activeCategory);

  const handleImageUpload = (projectId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          setCustomScreenshots((prev) => ({ ...prev, [projectId]: result }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'web':
        return <Layers className="w-3.5 h-3.5 text-[#8B5CF6]" />;
      case 'ai':
        return <Bot className="w-3.5 h-3.5 text-[#8B5CF6]" />;
      case 'automation':
        return <Workflow className="w-3.5 h-3.5 text-[#8B5CF6]" />;
      default:
        return <Code className="w-3.5 h-3.5 text-slate-500" />;
    }
  };

  return (
    <section id="projects" className="py-20 bg-slate-50/60 border-y border-slate-200/60 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div className="max-w-2xl">
            <p className="text-xs uppercase font-mono-custom text-[#7C3AED] tracking-wider mb-2 font-semibold">
              Portfolio
            </p>
            <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-[#0F172A] tracking-tight">
              Featured Work
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Real projects built with React, FastAPI, Gemini API &amp; n8n.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-1.5 p-1 bg-white rounded-xl border border-slate-200 shadow-xs self-start md:self-auto overflow-x-auto max-w-full">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveCategory(tab.id)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-all duration-200 cursor-pointer ${
                  activeCategory === tab.id
                    ? 'bg-[#8B5CF6] text-white shadow-sm'
                    : 'text-slate-600 hover:text-[#0F172A]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredProjects.map((project) => {
            const displayImg = customScreenshots[project.id] || project.thumbnail;

            return (
              <div
                key={project.id}
                className="group rounded-2xl bg-white border border-slate-200/80 hover:border-purple-200 hover:-translate-y-1.5 hover:shadow-xl hover:shadow-purple-500/10 transition-all duration-300 flex flex-col justify-between overflow-hidden"
              >
                {/* Visual Thumbnail Card Container */}
                <div className="relative w-full h-52 sm:h-56 bg-slate-900 border-b border-slate-100 overflow-hidden flex flex-col justify-between">
                  {displayImg ? (
                    <>
                      <img
                        src={displayImg}
                        alt={`${project.name} thumbnail`}
                        className="absolute inset-0 w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-105"
                        referrerPolicy="no-referrer"
                      />
                      {/* Gradient Overlay for high-contrast legible controls */}
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/25 to-slate-950/50 pointer-events-none" />

                      {/* Top Bar Overlay */}
                      <div className="relative z-10 p-4 flex items-center justify-between">
                        <div className="flex items-center gap-1.5 bg-black/40 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/15">
                          <span className="w-2 h-2 rounded-full bg-red-400/90" />
                          <span className="w-2 h-2 rounded-full bg-amber-400/90" />
                          <span className="w-2 h-2 rounded-full bg-emerald-400/90" />
                          <span className="text-[10px] font-mono-custom text-white/90 ml-1.5">
                            {project.id}
                          </span>
                        </div>

                        <div className="inline-flex items-center gap-1.5 px-3 py-1 text-[11px] font-mono-custom text-white bg-[#8B5CF6]/90 backdrop-blur-md rounded-full shadow-sm border border-purple-300/30">
                          {getCategoryIcon(project.category)}
                          <span className="capitalize font-semibold">{project.category}</span>
                        </div>
                      </div>

                      {/* Bottom Bar Overlay */}
                      <div className="relative z-10 p-4 flex items-center justify-between text-[11px]">
                        <button
                          type="button"
                          onClick={() => setSelectedProject(project)}
                          className="font-mono-custom text-white hover:text-purple-200 bg-white/20 hover:bg-white/30 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/20 font-medium transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-purple-200" />
                          <span>View Preview</span>
                        </button>

                        <label
                          htmlFor={`upload-${project.id}`}
                          className="inline-flex items-center gap-1.5 text-[11px] text-white/90 hover:text-white bg-black/40 hover:bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/20 transition-colors cursor-pointer shadow-xs"
                          title="Attach custom screenshot"
                        >
                          <ImageIcon className="w-3.5 h-3.5 text-purple-200" />
                          <span>Replace</span>
                        </label>
                        <input
                          id={`upload-${project.id}`}
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(project.id, e)}
                          className="hidden"
                        />
                      </div>
                    </>
                  ) : (
                    <div className="p-5 flex flex-col justify-between h-full bg-slate-100">
                      {/* Top Bar */}
                      <div className="flex items-center justify-between z-10">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                          <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                          <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
                          <span className="text-[11px] font-mono-custom text-slate-500 ml-2">
                            {project.id}
                          </span>
                        </div>

                        <div className="inline-flex items-center gap-1.5 px-3 py-1 text-[11px] font-mono-custom text-[#7C3AED] bg-white rounded-full shadow-xs border border-purple-100">
                          {getCategoryIcon(project.category)}
                          <span className="capitalize font-semibold">{project.category}</span>
                        </div>
                      </div>

                      {/* Middle Architecture Schematic Box */}
                      <div className="my-auto z-10">
                        <div className="p-3 rounded-xl bg-white/90 border border-slate-200/80 max-w-sm shadow-xs backdrop-blur-xs">
                          <p className="text-[10px] font-mono-custom text-[#7C3AED] font-semibold mb-0.5">
                            Architecture Pipeline
                          </p>
                          <p className="text-xs text-[#0F172A] font-medium">
                            {project.architectureNotes || 'Component Tree & State Flow'}
                          </p>
                        </div>
                      </div>

                      {/* Bottom Bar */}
                      <div className="flex items-center justify-between z-10 text-[11px] text-slate-500">
                        <button
                          type="button"
                          onClick={() => setSelectedProject(project)}
                          className="font-mono-custom text-[#7C3AED] hover:text-[#6D28D9] font-medium transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <Sparkles className="w-3 h-3" />
                          <span>View Architecture</span>
                        </button>

                        <label
                          htmlFor={`upload-${project.id}`}
                          className="inline-flex items-center gap-1 text-[11px] text-slate-600 hover:text-[#0F172A] cursor-pointer bg-white px-2.5 py-1 rounded-lg border border-slate-200 shadow-xs transition-colors"
                          title="Attach screenshot"
                        >
                          <ImageIcon className="w-3 h-3 text-slate-500" />
                          <span>Attach Screen</span>
                        </label>
                        <input
                          id={`upload-${project.id}`}
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(project.id, e)}
                          className="hidden"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Project Body */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Title & Tagline */}
                    <div className="mb-2">
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="font-display text-lg font-bold text-[#0F172A] group-hover:text-[#7C3AED] transition-colors">
                          {project.name}
                        </h3>
                        {project.badge && (
                          <span className="text-[10px] font-mono-custom text-[#7C3AED] bg-purple-50 border border-purple-200 px-2.5 py-0.5 rounded-full font-semibold">
                            {project.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 font-mono-custom mt-0.5">
                        {project.tagline}
                      </p>
                    </div>

                    {/* Description */}
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-3">
                      {project.description}
                    </p>

                    {/* Features as clean list */}
                    <div className="mb-4 space-y-1">
                      {project.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-xs text-slate-600">
                          <Check className="w-3.5 h-3.5 text-[#8B5CF6] shrink-0" />
                          <span className="truncate">{feature}</span>
                        </div>
                      ))}
                    </div>

                    {/* Technologies as colorful tags */}
                    <div className="mb-4">
                      <div className="flex flex-wrap gap-1.5">
                        {project.technologies.map((tech) => (
                          <span
                            key={tech}
                            className="text-[11px] font-mono-custom px-2.5 py-0.5 rounded-md bg-purple-50 text-[#7C3AED] border border-purple-100 font-medium"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      {project.githubUrl && (
                        <a
                          href={project.githubUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 hover:text-[#7C3AED] rounded-lg border border-slate-200 transition-all"
                        >
                          <Github className="w-3.5 h-3.5" />
                          <span>Code</span>
                        </a>
                      )}

                      {project.demoUrl && (
                        <a
                          href={project.demoUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-[#8B5CF6] hover:bg-[#7C3AED] rounded-lg shadow-sm transition-all"
                        >
                          <span>Live Demo</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => setSelectedProject(project)}
                      className="text-xs text-slate-500 hover:text-[#7C3AED] font-medium transition-colors cursor-pointer"
                    >
                      Details →
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive Project Details Modal */}
      {selectedProject && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200"
          onClick={() => setSelectedProject(null)}
        >
          <div 
            className="w-full max-w-xl bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-2xl relative animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setSelectedProject(null)}
              className="absolute top-5 right-5 p-2 text-slate-400 hover:text-slate-700 bg-slate-100 rounded-full transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-mono-custom text-[#7C3AED] bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200 font-semibold capitalize">
                {selectedProject.category}
              </span>
              {selectedProject.badge && (
                <span className="text-xs font-mono-custom text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-full">
                  {selectedProject.badge}
                </span>
              )}
            </div>

            <h3 className="font-display text-2xl font-bold text-[#0F172A] mb-1">
              {selectedProject.name}
            </h3>
            <p className="text-xs text-slate-500 font-mono-custom mb-3">
              {selectedProject.tagline}
            </p>

            {/* Visual Thumbnail Banner */}
            {(customScreenshots[selectedProject.id] || selectedProject.thumbnail) && (
              <div className="relative w-full h-44 sm:h-52 rounded-2xl overflow-hidden mb-4 border border-slate-200/80 shadow-sm bg-slate-900">
                <img
                  src={customScreenshots[selectedProject.id] || selectedProject.thumbnail}
                  alt={`${selectedProject.name} visual preview`}
                  className="w-full h-full object-cover object-top"
                  referrerPolicy="no-referrer"
                />
              </div>
            )}

            <p className="text-sm text-slate-600 leading-relaxed mb-4">
              {selectedProject.description}
            </p>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 mb-4">
              <p className="text-xs font-mono-custom text-[#7C3AED] font-semibold mb-1">
                Architecture Pipeline:
              </p>
              <p className="text-xs text-[#0F172A] font-medium">
                {selectedProject.architectureNotes || 'Component-driven frontend + REST service'}
              </p>
            </div>

            <div className="mb-4">
              <p className="text-xs font-bold text-[#0F172A] mb-2 uppercase tracking-wider">Key Features</p>
              <div className="space-y-1.5">
                {selectedProject.features.map((feat, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-slate-600">
                    <Check className="w-3.5 h-3.5 text-[#8B5CF6] shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <p className="text-xs font-bold text-[#0F172A] mb-2 uppercase tracking-wider">Technologies Used</p>
              <div className="flex flex-wrap gap-1.5">
                {selectedProject.technologies.map((t) => (
                  <span key={t} className="text-xs font-mono-custom px-2.5 py-1 rounded-lg bg-purple-50 text-[#7C3AED] border border-purple-100 font-medium">
                    {t}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-3 pt-3 border-t border-slate-100">
              {selectedProject.githubUrl && (
                <a
                  href={selectedProject.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
                >
                  <Github className="w-4 h-4 text-[#8B5CF6]" />
                  <span>GitHub Repository</span>
                </a>
              )}
              {selectedProject.demoUrl && (
                <a
                  href={selectedProject.demoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 text-xs font-semibold text-white bg-[#8B5CF6] hover:bg-[#7C3AED] rounded-xl transition-colors shadow-md shadow-purple-500/25"
                >
                  <span>Open Live Demo</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
