import React from 'react';
import { Github, Linkedin, Mail, ArrowUp } from 'lucide-react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-50 border-t border-slate-200/80 py-12 text-slate-500">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-slate-200/80">
          {/* Identity Wordmark matching Picto */}
          <div className="text-center md:text-left flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-[#8B5CF6] text-white font-display font-bold text-xs flex items-center justify-center shadow-xs">
              Z
            </span>
            <div>
              <a href="#home" className="font-display text-base sm:text-lg font-bold text-[#0F172A] hover:text-[#7C3AED] transition-colors">
                Muhammad Zaid
              </a>
              <p className="text-xs text-slate-500 font-mono-custom">
                Frontend Developer · AI Integration · Automation
              </p>
            </div>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-2.5 text-xs font-mono-custom">
            <a
              href="https://github.com/Zaid70-star"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 text-slate-600 hover:text-[#7C3AED] hover:bg-purple-50 bg-white rounded-xl border border-slate-200 shadow-xs transition-colors"
              aria-label="GitHub Profile"
              title="GitHub Profile (Zaid70-star)"
            >
              <Github className="w-4 h-4" />
            </a>

            <a
              href="https://www.linkedin.com/in/muhammad-zaid-6698b4382/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 text-slate-600 hover:text-[#7C3AED] hover:bg-purple-50 bg-white rounded-xl border border-slate-200 shadow-xs transition-colors"
              aria-label="LinkedIn Profile"
              title="LinkedIn Profile"
            >
              <Linkedin className="w-4 h-4" />
            </a>

            <a
              href="mailto:mzaidi1326@gmail.com"
              className="p-2.5 text-slate-600 hover:text-[#7C3AED] hover:bg-purple-50 bg-white rounded-xl border border-slate-200 shadow-xs transition-colors"
              aria-label="Direct Email"
              title="mzaidi1326@gmail.com"
            >
              <Mail className="w-4 h-4" />
            </a>

            <button
              type="button"
              onClick={scrollToTop}
              className="p-2.5 text-slate-600 hover:text-[#7C3AED] hover:bg-purple-50 bg-white rounded-xl border border-slate-200 shadow-xs transition-colors ml-1 cursor-pointer"
              title="Back to Top"
              aria-label="Scroll back to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2">
          <p>© {currentYear} Muhammad Zaid. All rights reserved.</p>
          <p className="font-mono-custom text-[11px] text-slate-400">
            Lahore, Pakistan · Built with React &amp; Tailwind CSS
          </p>
        </div>
      </div>
    </footer>
  );
};
