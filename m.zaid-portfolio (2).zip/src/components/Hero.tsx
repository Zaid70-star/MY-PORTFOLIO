import React, { useState, useEffect } from 'react';
import { ArrowDown, Upload, MapPin, GraduationCap, Sparkles } from 'lucide-react';

export const Hero: React.FC = () => {
  const [photoSrc, setPhotoSrc] = useState<string | null>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('zaid_portfolio_avatar');
      if (saved) {
        setPhotoSrc(saved);
      }
    } catch {
      // ignore
    }
  }, []);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          setPhotoSrc(result);
          try {
            localStorage.setItem('zaid_portfolio_avatar', result);
          } catch {
            // ignore
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <section id="home" className="pt-24 pb-16 md:pt-36 md:pb-24 relative overflow-hidden">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Heading, Bio, Say Hello CTA & Stat Strip matching Picto reference */}
          <div className="lg:col-span-7 flex flex-col items-start">
            {/* Availability Pill */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-50 border border-purple-200/60 text-xs font-medium text-[#7C3AED] mb-6">
              <span className="w-2 h-2 rounded-full bg-[#8B5CF6] animate-pulse" />
              <span>Available for Freelance &amp; Projects</span>
            </div>

            {/* Headline matching Picto reference "Hello, I’m Brooklyn Gilbert" */}
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#0F172A] leading-[1.12] mb-5">
              Hello, I’m <br />
              <span className="text-[#0F172A]">Muhammad Zaid</span>
            </h1>

            {/* Short Bio with subtle colored keywords like reference */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed mb-8 max-w-xl">
              I’m a Frontend <span className="text-[#E11D48] font-semibold">Developer</span> and <span className="text-[#7C3AED] font-semibold">Automator</span> based in Lahore, Pakistan. I build modern, responsive web applications and practical AI integrations through carefully crafted code and clean user-centric design.
            </p>

            {/* Actions: "Say Hello!" primary purple button like reference */}
            <div className="flex flex-wrap items-center gap-3.5 mb-10">
              <a
                href="#contact"
                className="px-7 py-3.5 text-sm font-semibold text-white bg-[#8B5CF6] hover:bg-[#7C3AED] rounded-xl shadow-lg shadow-purple-500/25 hover:shadow-xl hover:shadow-purple-500/35 hover:-translate-y-0.5 active:translate-y-0 transition-all"
              >
                Say Hello!
              </a>

              <a
                href="#projects"
                className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-sm hover:border-slate-300 transition-all hover:-translate-y-0.5"
              >
                <span>View My Work</span>
                <ArrowDown className="w-4 h-4 text-slate-500" />
              </a>
            </div>

            {/* Stat Strip at the bottom of hero matching reference "15 Y.  250+  58" */}
            <div className="w-full max-w-lg bg-white rounded-2xl p-4 sm:p-5 shadow-lg shadow-slate-200/50 border border-slate-100 grid grid-cols-3 divide-x divide-slate-100 text-center">
              <div className="px-2">
                <p className="font-display text-xl sm:text-2xl font-bold text-[#0F172A]">5+</p>
                <p className="text-xs text-slate-500 mt-0.5">Projects Built</p>
              </div>
              <div className="px-2">
                <p className="font-display text-xl sm:text-2xl font-bold text-[#0F172A]">100%</p>
                <p className="text-xs text-slate-500 mt-0.5">Responsive</p>
              </div>
              <div className="px-2">
                <p className="font-display text-xl sm:text-2xl font-bold text-[#7C3AED]">UET</p>
                <p className="text-xs text-slate-500 mt-0.5">Lahore CS</p>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Portrait Card with rounded corners matching reference */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="w-full max-w-md bg-white rounded-[28px] p-4 sm:p-5 shadow-xl shadow-slate-200/60 border border-slate-100 group transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/10">
              <div className="relative w-full aspect-[4/5] rounded-2xl overflow-hidden bg-gradient-to-b from-slate-100 to-slate-200/80 flex items-center justify-center">
                {photoSrc ? (
                  <img
                    src={photoSrc}
                    alt="Muhammad Zaid"
                    className="w-full h-full object-cover object-top"
                    referrerPolicy="no-referrer"
                    onError={() => setPhotoSrc(null)}
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center p-6 text-center">
                    <div className="w-24 h-24 rounded-full bg-[#8B5CF6] text-white flex items-center justify-center font-display font-bold text-3xl shadow-lg shadow-purple-500/30 mb-4">
                      MZ
                    </div>
                    <p className="font-display text-lg font-bold text-[#0F172A]">Muhammad Zaid</p>
                    <p className="text-xs text-slate-600 mt-1">Frontend Developer &amp; Automator</p>
                    <p className="text-[11px] text-slate-600 mt-0.5">Lahore, Pakistan</p>
                    <div className="mt-4 px-3 py-1 rounded-full bg-white/80 backdrop-blur-sm text-[11px] font-medium text-slate-600 border border-slate-200/60 shadow-xs">
                      Hover to change portrait photo
                    </div>
                  </div>
                )}

                {/* Upload Overlay */}
                <label
                  htmlFor="avatar-upload"
                  className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center cursor-pointer p-4 text-center text-white text-xs gap-2 backdrop-blur-xs"
                  title="Upload profile photo"
                >
                  <Upload className="w-6 h-6 text-[#8B5CF6]" />
                  <span className="font-semibold text-sm">Upload Your Photo</span>
                  <span className="text-[11px] text-slate-300">JPG, PNG, WebP</span>
                </label>
                <input
                  id="avatar-upload"
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </div>

              {/* Card Footer Detail */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#8B5CF6]" />
                  <span>Lahore, Pakistan</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-[#8B5CF6]" />
                  <span>UET Lahore</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
