import React from 'react';
import { Layers, Bot, Zap, CheckCircle2 } from 'lucide-react';

export const About: React.FC = () => {
  const whatICanBuild = [
    {
      title: 'Modern Frontends',
      description: 'Responsive, component-driven single page applications using React and Tailwind CSS.',
      icon: Layers,
    },
    {
      title: 'AI Integrations',
      description: 'Conversational chat systems and prompt utilities using the Gemini API & FastAPI.',
      icon: Bot,
    },
    {
      title: 'Workflow Automation',
      description: 'Automated webhook pipelines engineered in n8n to connect tools and eliminate busywork.',
      icon: Zap,
    },
  ];

  return (
    <section id="about" className="py-20 bg-slate-50/60 border-y border-slate-200/60 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-12">
          <p className="text-xs uppercase font-mono-custom text-[#7C3AED] tracking-wider mb-2 font-semibold">
            About Me
          </p>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-[#0F172A] tracking-tight">
            Practical engineering for real web and automation needs.
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Narrative Prose */}
          <div className="lg:col-span-7 space-y-4 text-slate-600 text-sm sm:text-base leading-relaxed">
            <p>
              I am a Computer Science undergraduate at <strong className="text-[#0F172A] font-semibold">UET Lahore</strong>, focused on modern frontend development, REST APIs, and business automation.
            </p>

            <p>
              My goal is to build software that is clean, responsive, and genuinely useful. On the frontend, I focus on <strong className="text-[#0F172A]">React</strong> and <strong className="text-[#0F172A]">Tailwind CSS</strong>. On the backend and automation side, I integrate <strong className="text-[#0F172A]">Python/FastAPI</strong> with the <strong className="text-[#7C3AED]">Gemini API</strong> and build <strong className="text-[#7C3AED]">n8n workflows</strong> to streamline operations.
            </p>

            {/* Commitments List */}
            <div className="pt-3 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm text-slate-700">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#8B5CF6] shrink-0" />
                <span>Responsive on all screen sizes</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#8B5CF6] shrink-0" />
                <span>Clean, maintainable components</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#8B5CF6] shrink-0" />
                <span>Working AI &amp; API integrations</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#8B5CF6] shrink-0" />
                <span>Direct, honest communication</span>
              </div>
            </div>
          </div>

          {/* Right Column: 3 Core Capabilities */}
          <div className="lg:col-span-5 space-y-3.5">
            <h3 className="text-xs uppercase font-mono-custom text-slate-600 tracking-wider font-semibold">
              Core Capabilities
            </h3>

            {whatICanBuild.map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.title}
                  className="p-4 bg-white border border-slate-200/80 rounded-2xl shadow-xs hover:shadow-md hover:border-purple-200 hover:-translate-y-0.5 transition-all group"
                >
                  <div className="flex items-center gap-3 mb-1.5">
                    <div className="p-2 rounded-xl bg-purple-50 text-[#8B5CF6] border border-purple-100 group-hover:bg-[#8B5CF6] group-hover:text-white transition-colors">
                      <Icon className="w-4 h-4" />
                    </div>
                    <h4 className="font-display text-sm font-bold text-[#0F172A] group-hover:text-[#7C3AED] transition-colors">
                      {item.title}
                    </h4>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed pl-11">
                    {item.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
