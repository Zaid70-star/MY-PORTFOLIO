import { Project } from '../types';

export const FEATURED_PROJECTS: Project[] = [
  {
    id: 'job-finder',
    name: 'Job Finder',
    tagline: 'Modern job board search engine with saved bookmarks & filtering',
    description:
      'A responsive React application featuring keyword search, dynamic routing, criteria filters, and saved job persistence via LocalStorage.',
    technologies: ['React', 'Vite', 'React Router', 'Tailwind CSS', 'REST API', 'Netlify'],
    features: [
      'Live search and real-time category filtering',
      'Dynamic job inspection with clean React Router paths',
      'Persistent saved jobs collection via LocalStorage',
    ],
    githubUrl: 'https://github.com/Zaid70-star/Job-Finder',
    demoUrl: 'https://github.com/Zaid70-star/Job-Finder',
    category: 'web',
    architectureNotes: 'React SPA · REST API · LocalStorage state layer',
    thumbnail: '/src/assets/images/thumb_job_finder_1794232567127.jpg',
  },
  {
    id: 'ai-web-app',
    name: 'AI Content Platform',
    tagline: 'Full-stack generative AI portal with auth & content dashboard',
    description:
      'An AI-powered web platform with Firebase user authentication, prompt generation workflows, and real-time Firestore database history.',
    technologies: ['React', 'Firebase', 'Gemini API', 'Tailwind CSS', 'Netlify'],
    features: [
      'Firebase Authentication & secure user state',
      'Interactive AI prompt generation workflows',
      'Real-time Firestore history & dashboard storage',
    ],
    demoUrl: 'https://aiideaandcontentgenerate.netlify.app/',
    githubUrl: 'https://github.com/Zaid70-star',
    category: 'ai',
    badge: 'Live Demo',
    architectureNotes: 'React · Firebase Auth & DB · Gemini API endpoints',
    thumbnail: '/src/assets/images/thumb_ai_content_1794232567967.jpg',
  },
  {
    id: 'ai-chatbot-api',
    name: 'AI Chatbot & API Backend',
    tagline: 'FastAPI microservice integrating Gemini API with structured prompts',
    description:
      'An asynchronous Python microservice routing conversational requests to Google Gemini, returning structured, low-latency AI responses.',
    technologies: ['Python', 'FastAPI', 'Gemini API', 'REST APIs', 'JSON'],
    features: [
      'Asynchronous FastAPI endpoints with fast response times',
      'Contextual prompt engineering for structured outputs',
      'Clean JSON schema for web & mobile integration',
    ],
    githubUrl: 'https://github.com/Zaid70-star',
    category: 'ai',
    architectureNotes: 'FastAPI ASGI microservice · Gemini API · JSON Contract',
    thumbnail: '/src/assets/images/thumb_ai_chatbot_1794232568364.jpg',
  },
  {
    id: 'ecommerce-store',
    name: 'E-Commerce Storefront',
    tagline: 'Fast responsive catalog with instant cart & wishlist management',
    description:
      'A clean e-commerce experience featuring dynamic product filtering, cart drawer state, and wishlist storage powered by React Context.',
    technologies: ['React', 'Tailwind CSS', 'Context API', 'REST API'],
    features: [
      'Dynamic catalog search with instant category filters',
      'Cart state management using React Context API',
      'Mobile-first responsive layout with fast checkout flow',
    ],
    githubUrl: 'https://github.com/Zaid70-star',
    category: 'web',
    architectureNotes: 'React Context · REST API · Responsive UI',
    thumbnail: '/src/assets/images/thumb_ecommerce_1794232568686.jpg',
  },
  {
    id: 'n8n-automation',
    name: 'n8n Workflow Automation',
    tagline: 'Automated webhook pipeline connecting APIs with AI enrichment',
    description:
      'An automated workflow in n8n listening to inbound webhooks, extracting structured data via AI, and routing data to external endpoints.',
    technologies: ['n8n', 'Webhooks', 'REST APIs', 'AI Integration'],
    features: [
      'Webhook listener routing inbound business triggers',
      'AI prompt node parsing unstructured incoming data',
      'Zero-code API synchronization eliminating manual work',
    ],
    githubUrl: 'https://github.com/Zaid70-star',
    category: 'automation',
    architectureNotes: 'Webhook Trigger → AI Parser Node → API Payload Sync',
    thumbnail: '/src/assets/images/thumb_n8n_workflow_1794232567948.jpg',
  },
];
