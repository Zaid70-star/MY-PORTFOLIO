import { SkillCategory } from '../types';

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    title: 'Frontend Development',
    id: 'frontend',
    description: 'Component architecture, responsive layouts, and state management.',
    skills: [
      { name: 'React', highlight: true },
      { name: 'JavaScript (ES6+)', highlight: true },
      { name: 'Tailwind CSS', highlight: true },
      { name: 'HTML5 & CSS3' },
      { name: 'React Router' },
      { name: 'DOM Manipulation' },
      { name: 'Responsive UI', highlight: true },
    ],
  },
  {
    title: 'Backend & APIs',
    id: 'backend',
    description: 'RESTful endpoints, asynchronous handlers, and database connections.',
    skills: [
      { name: 'Python', highlight: true },
      { name: 'FastAPI', highlight: true },
      { name: 'REST APIs', highlight: true },
      { name: 'Firebase' },
      { name: 'SQL', note: 'Basic' },
    ],
  },
  {
    title: 'AI Integration',
    id: 'ai',
    description: 'Generative models, contextual prompt engineering, and chat endpoints.',
    skills: [
      { name: 'Gemini API', highlight: true },
      { name: 'AI API Integration', highlight: true },
      { name: 'AI Chatbots', highlight: true },
      { name: 'Prompt Engineering' },
      { name: 'Basic AI Agents' },
      { name: 'AI-Powered Web Apps', highlight: true },
    ],
  },
  {
    title: 'Workflow Automation',
    id: 'automation',
    description: 'Connecting services, webhooks, and asynchronous data triggers.',
    skills: [
      { name: 'n8n', highlight: true },
      { name: 'Workflow Automation', highlight: true },
      { name: 'API Automation' },
      { name: 'Lead Gen Automation' },
      { name: 'AI Workflow Integration', highlight: true },
    ],
  },
  {
    title: 'Tools & Foundations',
    id: 'tools',
    description: 'Version control, developer toolchains, and programming core.',
    skills: [
      { name: 'Git & GitHub', highlight: true },
      { name: 'Netlify' },
      { name: 'C++' },
      { name: 'OOP Foundations' },
    ],
  },
];
