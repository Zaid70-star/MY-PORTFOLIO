import { BuildingMilestone } from '../types';

export const BUILDING_MILESTONES: BuildingMilestone[] = [
  {
    period: '2025 – Present',
    title: 'BS Computer Science',
    focus: 'UET Lahore',
    description: 'Core curriculum in Data Structures, Algorithms, Object-Oriented Programming (C++), and Database systems.',
    tags: ['Data Structures', 'Algorithms', 'C++', 'OOP', 'SQL'],
  },
  {
    period: '2024 – Present',
    title: 'Frontend Development',
    focus: 'React & Component Architecture',
    description: 'Building responsive single-page web applications with React, Tailwind CSS, and REST API integrations.',
    tags: ['React', 'JavaScript', 'Tailwind CSS', 'Vite', 'REST APIs'],
  },
  {
    period: '2024 – Present',
    title: 'AI Integrations & APIs',
    focus: 'Gemini API & Python/FastAPI',
    description: 'Developing backend microservices in Python & FastAPI connecting web clients to the Google Gemini API.',
    tags: ['Gemini API', 'Python', 'FastAPI', 'Prompt Engineering', 'Firebase'],
  },
  {
    period: '2024 – Present',
    title: 'Workflow Automation',
    focus: 'n8n & Process Orchestration',
    description: 'Automating multi-app data flow, webhook triggers, and notification routing using n8n.',
    tags: ['n8n', 'Webhooks', 'API Automation', 'JSON'],
  },
];
