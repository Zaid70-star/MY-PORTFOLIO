import { Service } from '../types';

export const SERVICES: Service[] = [
  {
    id: 'web-dev',
    title: 'Modern Web Applications',
    problem: 'Slow, cluttered, or unresponsive websites that fail on mobile devices and lose visitors.',
    solution: 'Build fast, responsive web apps using React and Tailwind CSS with clean component architecture.',
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Vite'],
    icon: 'Layout',
  },
  {
    id: 'ai-features',
    title: 'AI Feature & Chatbot Integration',
    problem: 'Apps that lack modern AI capabilities or spend hours answering repetitive inquiries.',
    solution: 'Integrate conversational bots and prompt-driven utilities using Google Gemini and FastAPI.',
    technologies: ['Gemini API', 'FastAPI', 'Python', 'REST APIs'],
    icon: 'BotMessageSquare',
  },
  {
    id: 'workflow-automation',
    title: 'Workflow Automation',
    problem: 'Teams wasting hours manually copying data between tools, sheets, and notification channels.',
    solution: 'Design n8n workflows that connect webhooks, parse data with AI, and dispatch automated tasks.',
    technologies: ['n8n', 'Webhooks', 'REST APIs', 'JSON'],
    icon: 'Workflow',
  },
  {
    id: 'api-integration',
    title: 'REST API & Backend Connections',
    problem: 'Frontends isolated from databases, external services, or automated backend endpoints.',
    solution: 'Connect client applications to robust REST endpoints with error handling and fast data fetching.',
    technologies: ['FastAPI', 'REST APIs', 'Firebase', 'Fetch API'],
    icon: 'Cpu',
  },
];
