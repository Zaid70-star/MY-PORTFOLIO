import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Skills } from './components/Skills';
import { Projects } from './components/Projects';
import { Services } from './components/Services';
import { HowICanHelp } from './components/HowICanHelp';
import { Experience } from './components/Experience';
import { SocialHub } from './components/SocialHub';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] relative overflow-x-hidden selection:bg-purple-500/20 selection:text-purple-900">
      {/* Soft atmospheric gradient wash inspired by the Picto backdrop */}
      <div 
        className="fixed top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-gradient-to-b from-purple-100/60 via-sky-50/40 to-transparent blur-3xl pointer-events-none -z-10" 
        aria-hidden="true"
      />

      <Navbar />
      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Services />
        <HowICanHelp />
        <Experience />
        <SocialHub />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
